USE TStore

-- PU001
UPDATE Cloth
SET ClothStock += 30
WHERE ClothID = 'CL004'

UPDATE Cloth
SET ClothStock += 10
WHERE ClothID = 'CL002'

-- PU002
UPDATE Cloth
SET ClothStock += 8
WHERE ClothID = 'CL003'

-- PU003
UPDATE Cloth
SET ClothStock += 8
WHERE ClothID = 'CL004'

-- PU004
UPDATE Cloth
SET ClothStock += 5
WHERE ClothID = 'CL002'

-- PU005
UPDATE Cloth
SET ClothStock += 10
WHERE ClothID = 'CL001'

UPDATE Cloth
SET ClothStock += 10
WHERE ClothID = 'CL002'
-- SA001
UPDATE Cloth
SET ClothStock -= 3
WHERE ClothID = 'CL001'

UPDATE Cloth
SET ClothStock -= 3
WHERE ClothID = 'CL002'

UPDATE Cloth
SET ClothStock -= 2
WHERE ClothID = 'CL004'

-- SA002

UPDATE Cloth
SET ClothStock -= 2
WHERE ClothID = 'CL003'

UPDATE Cloth
SET ClothStock -= 1
WHERE ClothID = 'CL002'

-- PU006
UPDATE Cloth
SET ClothStock += 5
WHERE ClothID = 'CL003'

--SA003
UPDATE Cloth
SET ClothStock -= 2
WHERE ClothID = 'CL004'

--SA004
UPDATE Cloth
SET ClothStock -= 4
WHERE ClothID = 'CL002'

UPDATE Cloth
SET ClothStock -= 10
WHERE ClothID = 'CL003'

UPDATE Cloth
SET ClothStock -= 2
WHERE ClothID = 'CL001'

-- SA005
UPDATE Cloth
SET ClothStock -= 4
WHERE ClothID = 'CL002'

-- SA006
UPDATE Cloth
SET ClothStock -= 1
WHERE ClothID = 'CL001'

UPDATE Cloth
SET ClothStock -= 5
WHERE ClothID = 'CL002'

-- PU007
UPDATE Cloth
SET ClothStock += 12
WHERE ClothID = 'CL001'

UPDATE Cloth
SET ClothStock += 10
WHERE ClothID = 'CL004'

-- SA007 
UPDATE Cloth
SET ClothStock -= 2
WHERE ClothID = 'CL002'

UPDATE Cloth
SET ClothStock -= 4
WHERE ClothID = 'CL004'

-- SA008 

UPDATE Cloth
SET ClothStock -= 8
WHERE ClothID = 'CL003'


