USE TStore

INSERT INTO ClothCategory VALUES('CA001', 'Shirt')
INSERT INTO ClothCategory VALUES('CA002', 'Dress')

INSERT INTO Cloth VALUES ('CL001', 'CA001', 'Mic Yol', 35000, 50)
INSERT INTO Cloth VALUES ('CL002', 'CA002', 'Lol Vitton', 50000, 40)
INSERT INTO Cloth VALUES ('CL003', 'CA002', 'Bob Secret', 46000, 55)
INSERT INTO Cloth VALUES ('CL004', 'CA001', 'Sport Hordan', 30000, 30)

INSERT INTO Vendor VALUES('VE001', 'Saad Boi', 'N-9 Bright street', '081279001234', '544d8o1@gmail.com')
INSERT INTO Vendor VALUES('VE002', 'Muhhamad Hasaad', 'J-123 Dim street', '083112340981', 'Msaad@yahoo.com')
INSERT INTO Vendor VALUES('VE003', 'Sonia Hill', '54th Dark street', '081279001234', 'SonHill52@gmail.com')

INSERT INTO Customer VALUES('CU001', 'Jovia Flux', 'I-09 Mint street', '087654231111', 'F', 'Jovlx12@mail.com')
INSERT INTO Customer VALUES('CU002', 'Pol Koz', 'V-5 Circus street', '089912094857', 'F', 'CozPol4@magic.com')
INSERT INTO Customer VALUES('CU003', 'Mina Burns', '12th Mittens street', '081748579517', 'F', '0Min4Burns@gmail.com')
INSERT INTO Customer VALUES('CU004', 'Vol Sullivan', '91st Inc street', '086665475555', 'M', 'Monst32@gail.com')

INSERT INTO Staff VALUES('ST001', 'Mike Brown', 'J9 King street', '088877715432', 'M', 'Bmike88@fil.com', 4000000)
INSERT INTO Staff VALUES('ST002', 'Justin Ortiz', 'J-5 Forest Sqr', '081274189635', 'M', 'Jortz@gmail.com', 4400000)
INSERT INTO Staff VALUES('ST003', 'Fay Nix', '21st Ranch street', '081122449912', 'F', 'Fay12@hmoon.com', 6000000)
INSERT INTO Staff VALUES('ST004', 'Peach White', 'B-15 Beachside Street', '081270708888', 'F', 'Peachit@ari.com', 4900000)
INSERT INTO Staff VALUES('ST005', 'Lee Yao', '10th Med Sqr', '081234567890', 'M', 'Shhyao@cin.com', 5500000)

INSERT INTO SaleTransaction VALUES('SA001', 'CU001','ST005','20210429 10:30:00 AM')
INSERT INTO SaleTransaction VALUES('SA002', 'CU001','ST002','20210430 01:10:00 AM')
INSERT INTO SaleTransaction VALUES('SA003', 'CU001','ST003','20210501 11:01:50 AM')
INSERT INTO SaleTransaction VALUES('SA004', 'CU004','ST001','20210503 04:27:12 PM')
INSERT INTO SaleTransaction VALUES('SA005', 'CU004','ST004','20210507 06:50:47 PM')
INSERT INTO SaleTransaction VALUES('SA006', 'CU002','ST001','20210511 09:23:40 AM')
INSERT INTO SaleTransaction VALUES('SA007', 'CU003','ST003','20210520 02:52:07 AM')
INSERT INTO SaleTransaction VALUES('SA008', 'CU002','ST002','20210526 07:00:00 PM')

INSERT INTO PurchaseTransaction VALUES('PU001', 'ST005', 'VE001', '20210301 10:30:00 AM')
INSERT INTO PurchaseTransaction VALUES('PU002', 'ST002', 'VE002', '20210305 01:10:00 AM')
INSERT INTO PurchaseTransaction VALUES('PU003', 'ST003', 'VE003', '20210402 11:01:50 AM')
INSERT INTO PurchaseTransaction VALUES('PU004', 'ST001', 'VE003', '20210402 04:27:12 PM')
INSERT INTO PurchaseTransaction VALUES('PU005', 'ST004', 'VE002', '20210407 06:50:47 PM')
INSERT INTO PurchaseTransaction VALUES('PU006', 'ST001', 'VE002', '20210501 09:23:40 AM')
INSERT INTO PurchaseTransaction VALUES('PU007', 'ST003', 'VE001', '20210518 02:52:07 AM')

INSERT INTO PurchaseDetail VALUES('PU001', 'CL004', 30)
INSERT INTO PurchaseDetail VALUES('PU001', 'CL002', 10)
INSERT INTO PurchaseDetail VALUES('PU002', 'CL003', 8)
INSERT INTO PurchaseDetail VALUES('PU003', 'CL004', 8)
INSERT INTO PurchaseDetail VALUES('PU004', 'CL002', 5)

INSERT INTO PurchaseDetail VALUES('PU005', 'CL001', 10)
INSERT INTO PurchaseDetail VALUES('PU005', 'CL002', 10)
INSERT INTO PurchaseDetail VALUES('PU006', 'CL003', 5)
INSERT INTO PurchaseDetail VALUES('PU007', 'CL001', 12)
INSERT INTO PurchaseDetail VALUES('PU007', 'CL004', 10)

INSERT INTO SaleDetail VALUES('SA001', 'CL001', 3) 
INSERT INTO SaleDetail VALUES('SA001', 'CL002', 3) 
INSERT INTO SaleDetail VALUES('SA001', 'CL004', 2) 
INSERT INTO SaleDetail VALUES('SA002', 'CL003', 2) 
INSERT INTO SaleDetail VALUES('SA002', 'CL002', 1) 

INSERT INTO SaleDetail VALUES('SA003', 'CL004', 2) 
INSERT INTO SaleDetail VALUES('SA004', 'CL002', 4) 
INSERT INTO SaleDetail VALUES('SA004', 'CL003', 10) 
INSERT INTO SaleDetail VALUES('SA004', 'CL001', 2) 
INSERT INTO SaleDetail VALUES('SA005', 'CL002', 4) 

INSERT INTO SaleDetail VALUES('SA006', 'CL001', 1) 
INSERT INTO SaleDetail VALUES('SA006', 'CL002', 5) 
INSERT INTO SaleDetail VALUES('SA007', 'CL002', 2) 
INSERT INTO SaleDetail VALUES('SA007', 'CL004', 4) 
INSERT INTO SaleDetail VALUES('SA008', 'CL003', 8) 





