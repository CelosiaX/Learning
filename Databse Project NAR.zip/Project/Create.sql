CREATE DATABASE TStore

USE TStore

CREATE TABLE Staff(
	StaffID CHAR(5) PRIMARY KEY NOT NULL,
	[StaffName] VARCHAR(30),
	[StaffAddress] VARCHAR(50),
	[StaffPhoneNum] VARCHAR(12),
	[StaffGender] CHAR(1),
	[StaffEmail] VARCHAR(30),
	StaffSalary INT,
	CONSTRAINT StaffId_Chk CHECK (StaffID LIKE 'ST[0-9][0-9][0-9]'),
	CONSTRAINT StaffPhoneNum_Chk CHECK (StaffPhoneNum LIKE '08%'),
	CONSTRAINT StaffGender_Chk CHECK (StaffGender IN('F', 'M')),
	CONSTRAINT StaffSalary_Chk CHECK (StaffSalary >= 3000000)	
)

CREATE TABLE Customer(
	CustomerID CHAR(5) PRIMARY KEY NOT NULL,
	[CustomerName] VARCHAR(30),
	[CustomerAddress] VARCHAR(50),
	[CustomerPhoneNum] VARCHAR(12),
	[CustomerGender] CHAR(1),
	CustomerEmail VARCHAR(30),
	CONSTRAINT CustomerID CHECK (CustomerID LIKE 'CU[0-9][0-9][0-9]'),
	CONSTRAINT CustomerGender_Chk CHECK (CustomerGender IN('F', 'M')),
	CONSTRAINT CustomerPhone_Chk CHECK (CustomerPhoneNum LIKE '08%')
)

CREATE TABLE ClothCategory(
	ClothCategoryID CHAR(5) PRIMARY KEY NOT NULL,
	ClothCategoryName VARCHAR(20),
	CONSTRAINT ClothCatId_Chk CHECK (ClothCategoryID LIKE 'CA[0-9][0-9][0-9]')
)

CREATE TABLE Cloth(
	ClothID CHAR(5) PRIMARY KEY NOT NULL,
	ClothCategoryID CHAR(5) REFERENCES ClothCategory(ClothCategoryID),
	ClothBrand VARCHAR(20), 
	ClothPrice INT,
	ClothStock INT,
	CONSTRAINT ClothID_Chk CHECK (ClothID LIKE 'CL[0-9][0-9][0-9]'),
	CONSTRAINT ClothPrice_Chk CHECK (ClothPrice >= 2000),
	CONSTRAINT ClothBrand_Chk CHECK (LEN(ClothBrand) > 5)
)

CREATE TABLE Vendor(
	VendorID CHAR(5) PRIMARY KEY NOT NULL,
	VendorName VARCHAR(20),
	VendorAddress VARCHAR(50),
	VendorPhoneNumber VARCHAR(12),
	VendorEmail VARCHAR(20),
	CONSTRAINT VendorID_Chk CHECK (VendorID LIKE 'VE[0-9][0-9][0-9]'),
	CONSTRAINT VendorPhoneNumber_Chk CHECK (VendorPhoneNumber LIKE '08%')
)

CREATE TABLE PurchaseTransaction(
	PurchaseTransactionID CHAR(5) PRIMARY KEY NOT NULL,
	StaffID CHAR(5) REFERENCES Staff(StaffID),
	VendorID CHAR(5) REFERENCES Vendor(VendorID),
	PurchaseDate DATETIME,
	CONSTRAINT ptID_Chk CHECK (PurchaseTransactionID LIKE 'PU[0-9][0-9][0-9]'),
	CONSTRAINT PurchaseDate_Chk CHECK (DATEDIFF(HOUR, PurchaseDate, GETDATE()) > 0)
)

CREATE TABLE PurchaseDetail(
	PurchaseTransactionID CHAR(5) REFERENCES PurchaseTransaction(PurchaseTransactionID),
	ClothID CHAR(5) REFERENCES Cloth(ClothID),
	PurchaseQuantity INT	
)


CREATE TABLE SaleTransaction(
	SaleTransactionID CHAR(5) PRIMARY KEY NOT NULL,
	CustomerID CHAR(5) REFERENCES Customer(CustomerID),
	StaffID CHAR(5) REFERENCES Staff(StaffID),
	SaleDate DATETIME,
	CONSTRAINT stID_Chk CHECK (SaleTransactionID LIKE 'SA[0-9][0-9][0-9]'),
	CONSTRAINT SaleDate_Chk CHECK (DATEDIFF(HOUR, SaleDate, GETDATE()) > 0)
)

CREATE TABLE SaleDetail(
	SaleTransactionID CHAR(5) REFERENCES SaleTransaction(SaleTransactionid),
	ClothID CHAR(5) REFERENCES Cloth(ClothID),
	SaleQuantity INT,
)
