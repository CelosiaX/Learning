USE TStore
-- Untested
-- 1
SELECT [Transaction Count] = COUNT(pt.PurchaseTransactionID),
StaffName, VendorName
FROM PurchaseTransaction pt
JOIN Staff s ON pt.StaffID = s.StaffID
JOIN Vendor v ON pt.VendorID = v.VendorID
WHERE (StaffSalary BETWEEN 5000000 AND 10000000) 
AND (VendorName LIKE '%o%')
GROUP BY StaffName, VendorName

-- 2
SELECT SaleID = st.SaleTransactionID, SaleDate, CustomerName, CustomerAddress
FROM SaleTransaction st
JOIN Customer c ON st.CustomerID = c.CustomerID
JOIN SaleDetail sd ON st.SaleTransactionID = sd.SaleTransactionID
JOIN Cloth ON sd.ClothID = Cloth.ClothID
WHERE DATEPART(DAY, SaleDate) = 15
GROUP BY sd.SaleTransactionID, SaleDate, CustomerName, CustomerAddress
HAVING SUM(ClothPrice) > 150000

-- 3
SELECT [Month] = DATENAME(MONTH, DATEADD(MONTH, -1, GETDATE())), 
[Total Transaction] = COUNT(st.SaleTransactionID),
[Cloth Sold Quantity] = SUM(sd.SaleQuantity)
FROM SaleTransaction st
JOIN SaleDetail sd ON st.SaleTransactionID = sd.SaleTransactionID
JOIN Cloth c ON sd.ClothID = c.ClothID
JOIN Staff s ON st.StaffID = s.StaffID
WHERE s.StaffGender = 'F'AND c.ClothPrice >= 70000 AND DATEDIFF(MONTH, SaleDate, GETDATE()) = 1

-- 4
SELECT [Brand Last Name] = REVERSE(SUBSTRING(REVERSE(ClothBrand), 1, CHARINDEX(' ', REVERSE(ClothBrand) - 1))),
[Max Quantity Sold] =  MAX(SaleQuantity)
FROM SaleDetail sd
JOIN Cloth c ON sd.ClothID = c.ClothID
GROUP BY sd.SaleTransactionID, sd.ClothID, ClothBrand
HAVING SUM(SaleQuantity) BETWEEN 6 AND 9

-- 5
SELECT ClothBrand, ClothPrice, ClothStock FROM PurchaseTransaction pt
JOIN Vendor v ON pt.VendorID = v.VendorID
JOIN PurchaseDetails pd ON pt.PurchaseTransactionID = pd.PurchaseTransactionID
JOIN Cloth c ON pd.ClothID = c.ClothID
WHERE VendorName LIKE 'Saad%'
GROUP BY pt.VendorID, ClothBrand, ClothPrice, ClothStock
HAVING ClothPrice BETWEEN AVG(ClothPrice) - 35000 AND AVG(ClothPrice)

-- 6
SELECT [Sales date] = CONVERT(VARCHAR, SaleDate, 101), ClothBrand, SaleQuantity
FROM SaleDetail sd
JOIN SaleTransaction st ON sd.SaleTransactionID = st.SaleTransactionID
JOIN Cloth c ON sd.ClothID = c.ClothID
GROUP BY sd.SaleTransactionID, ClothBrand, SaleQuantity, SaleDate
HAVING SUM(SaleQuantity) > (
	SELECT SUM(SaleQuantity) FROM SaleDetail sd
	JOIN SaleTransaction st ON sd.SaleTransactionID = st.SaleTransactionID
	WHERE MONTH(SaleDate) = 5
	GROUP BY MONTH(SaleDate)
)
ORDER BY SaleQuantity ASC

---dateadd(month, datediff(month, 0, SaleDate),0)

-- 7 

SELECT [PurchaseID] = pt.PurchaseTransactionID, [Staff Name] = LOWER(StaffName),  [Staff Salary] = 'IDR ' + CAST(StaffSalary AS VARCHAR)
, [Purchase Date] = CONVERT(VARCHAR, PurchaseDate, 107), [Total Quantity] = SUM(PurchaseQuantity)
FROM PurchaseTransaction pt
JOIN Staff s ON pt.StaffID = s.StaffID
JOIN PurchaseDetails pd ON pt.PurchaseTransactionID = pd.PurchaseTransactionID
GROUP BY pt.PurchaseTransactionID, StaffName, StaffSalary, PurchaseDate
HAVING SUM(PurchaseQuantity) > (
SELECT MIN(pd.PurchaseQuantity) FROM PurchaseTransaction pt
JOIN PurchaseDetails pd ON pt.PurchaseTransactionID = pd.PurchaseTransactionID
WHERE MONTH(PurchaseDate) = 4
)

SELECT [Vendor ID] = SUBSTRING(pt.VendorID, 3, 3), VendorName, 
[Clothes Bought] = CAST(SUM(PurchaseQuantity) AS VARCHAR) + 'piece(s)',
[Vendor phone] = '+62' + SUBSTRING(VendorPhoneNumber, 3, LEN(VendorPhoneNumber) - 2)
FROM PurchaseTransaction pt
JOIN Vendor v ON pt.VendorID = v.VendorID
JOIN PurchaseDetails pd ON pt.PurchaseTransactionID = pd.PurchaseTransactionID
GROUP BY pt.VendorID, VendorName, VendorPhoneNumber
HAVING SUM(PurchaseQuantity) BETWEEN (
SELECT AVG(PurchaseQuantity) FROM PurchaseDetails
)
AND 99


-- 9

CREATE VIEW StoreSaleView AS
SELECT [SalesID] = sd.SaleTransactionID, CustomerName, CustomerPhoneNum,
[Cloth average price] = 'IDR ' + CAST(AVG(ClothPrice) AS VARCHAR),
[Sales Quantity] = CAST(SUM(SaleQuantity) AS VARCHAR)+ ' piece(s)'
FROM SaleTransaction st
JOIN Customer c ON st.CustomerID = c.CustomerID
JOIN SaleDetail sd ON st.SaleTransactionID = sd.SaleTransactionID
JOIN Cloth ON sd.ClothID = Cloth.ClothID
GROUP BY sd.SaleTransactionID, CustomerName, CustomerPhoneNum
HAVING AVG(ClothPrice) > 100000 AND SUM(SaleQuantity) > 4

CREATE VIEW  StorePurchaseView AS
SELECT [Month] = DATENAME(MONTH,PurchaseDate), [Minimum Purchased Quantity] = MIN(PurchaseQuantity),
[Purchased Cloth Count] = SUM(PurchaseQuantity)
FROM PurchaseTransaction pt
JOIN PurchaseDetails pd ON pt.PurchaseTransactionID = pd.PurchaseTransactionID
GROUP BY pt.PurchaseTransactionID, PurchaseDate
HAVING MIN(PurchaseQuantity) > 10 AND SUM(PurchaseQuantity) > 1

